## 참고한 자료:
클라썸
www.classum.com/main/course/29358/community/63
- make 실행방법에 대하여 질문 하고, man make를 통해서 해결했습니다.

www.classum.com/main/course/29358/community/89
- 데이터에 대하여 질문을 했던 내역, 고기훈 조교님께서 유니크 하다고 하셔서 subtask1에서 2개 이상의 title이 한 라인의 있는 경우,
첫번째것만 쓰도록 했습니다.

www.classum.com/main/course/29358/community/102
- 제출 폴더 구조 양식에 대한 질문, 고기훈 조교님

## 코멘트
- 하둡을 공부하기에 좋은 과제인 것 같습니다. 기존 lsh 알고리즘에서 bucketing을 hadoop의 mapreduce 특징을 이용해서 구현하는 부분이 하둡의 실행 구조를 이해하는데 좋은 예제인 것 같습니다.

감사합니다.