도움을 받은 자료:

이분 그래프: 
https://networkx.org/documentation/stable/reference/algorithms/bipartite.html

https://en.wikipedia.org/wiki/Bipartite_hypergraph
위키 페디아 자료에서 hypergraph의 일부라는 것을 보고 이분 그래프로써 degree centrality를 계산하였습니다.
단순히 각 노드의 degree와 같은 값을 가지지만, normalization이 되었는지 유무차이가 있다고 생각합니다.

상관관계 분석:
https://blog.naver.com/PostView.naver?blogId=breezehome50&logNo=222353492058&redirect=Dlog&widgetTypeCall=true&directAccess=false
https://a292run.tistory.com/entry/Pearson-and-Spearman-Rank-Correlation-Coefficient-%E2%80%94-Explained-1

Metrics
centrality = https://dodonam.tistory.com/330
저자 영향도 metric = https://www.rosenberglab.net/impact_a_index.html