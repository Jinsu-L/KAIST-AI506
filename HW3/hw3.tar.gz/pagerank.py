def run_pagerank_one_step(hypergraph, pr_scores, damping_factor):
    pass

def run_advanced_pagerank_one_step(hypergraph, pr_scores, damping_factor):
    pass

def run_pagerank(hypergraph, pr_scores, damping_factor, use_weight=False):
    pass
