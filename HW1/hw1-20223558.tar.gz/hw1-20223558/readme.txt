## 참고한 자료:
블로그 :
https://blog.naver.com/PostView.naver?blogId=sw4r&logNo=222224817264&parentCategoryNo=&categoryNo=176&viewDate=&isShowPopularPosts=false&from=postView

https://haandol.github.io/2019/05/25/minhash-algorithm-explained.html

post :
https://towardsdatascience.com/understanding-locality-sensitive-hashing-49f6d1f6134


클라썸
www.classum.com/main/course/29358/community/36
- 이규한 TA님의 도움으로 candidatePairs 부분에 대하여 작성을 하였습니다.

www.classum.com/main/course/29358/community/54
precision@10 계산시 s threshold가 있어야 할 것 같다는 것을 이 글을 보고 생각하였습니다.

## 코멘트
* sparse한 피드백 정보가 있는 영화에 대하여 좀 더 분석하는 부분이 있으면 어떨까합니다.
* 마지막 case study에서 관련 영화이 잘 나오지 않는 케이스에 대하여 sparse한 정도에 따라서 precision을 그리면 어떨까합니다.

감사합니다.